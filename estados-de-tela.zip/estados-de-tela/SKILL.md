---
name: "estados-de-tela"
description: "Use when building any screen or component that displays data, so it handles more than the happy path. Requires explicit handling of loading, empty, error, unauthorized, offline, partial-failure and large-dataset states. Apply before considering any data-driven screen complete."
---

## ESTADOS DE TELA

Toda tela que exibe dado precisa tratar TODOS os estados abaixo. Entregar
só o caminho feliz é entregar protótipo, não produto.

FRONTEIRA: esta skill é a DONA de QUAIS estados existem e o que cada um
mostra. Como cada estado se comporta em tela pequena, ver mobile-first.
O texto exibido em cada um, ver escrita-cliente. A aparência (skeleton,
cores, espaçamento), ver design-system.

### Estados obrigatórios

1. CARREGANDO

- Skeleton que reproduz a forma do conteúdo, de preferência a spinner
genérico.
- Reservar o espaço final para não haver salto de layout (CLS).
- Se passar de ~10s, oferecer feedback adicional ou opção de cancelar.
- Não piscar loading para resposta muito rápida (delay mínimo).

2. VAZIO — PRIMEIRO ACESSO

- Nunca deixar tela em branco.
- Explicar o que aparece ali, por que está vazio e qual a próxima ação.
- Botão de ação primária visível.
- Tom acolhedor: é o primeiro contato do usuário com a funcionalidade.

3. VAZIO — SEM RESULTADO DE BUSCA/FILTRO

- Diferente do vazio de primeiro acesso.
- Mostrar o que foi buscado.
- Oferecer limpar filtros ou sugerir alternativa.

4. ERRO

- Mensagem em linguagem comum, sem código técnico cru.
- Botão de "tentar novamente".
- Preservar o que o usuário já tinha feito.
- Distinguir erro do sistema de erro do usuário.

5. SEM PERMISSÃO

- Deixar claro que existe, mas ele não tem acesso — ou esconder por
completo, conforme a regra de negócio (não vazar existência de dado
sensível).
- Indicar como obter acesso, se aplicável.

6. OFFLINE / SEM CONEXÃO

- Detectar e avisar.
- Não perder dado preenchido.
- Reenviar automaticamente ao voltar, quando fizer sentido.

7. MUITOS DADOS

- Paginação ou scroll infinito — nunca carregar tudo.
- Virtualização em lista longa.
- Busca e filtro quando passar de algumas dezenas de itens.
- Indicar total de resultados.

8. SUCESSO PARCIAL

- Quando parte da operação funcionou: dizer exatamente o que deu certo
e o que falhou, e permitir reprocessar só o que falhou.

9. DADO DESATUALIZADO

- Em tela que depende de dado que muda (dashboard, status de pedido):
indicar quando foi atualizado e oferecer atualizar.

### Estados de item individual

Além da tela, componentes precisam de: hover, foco, ativo, desabilitado,
carregando (botão), selecionado, erro.

### Regra de implementação

Ao criar uma tela com dado, escrever os estados ANTES de estilizar o
caminho feliz. É mais rápido que voltar depois e evita o clássico
"funciona só quando tem dado".

### Ao final, reportar

Quais dos nove estados se aplicam a esta tela, e como cada um foi  
tratado. Se algum não se aplica, justificar.