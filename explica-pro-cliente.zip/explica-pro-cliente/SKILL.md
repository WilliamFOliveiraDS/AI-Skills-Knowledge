---
name: "explica-pro-cliente"
description: "Use when the user needs to communicate technical work to a non-technical audience: delivery summaries, progress updates, explaining a delay or a bug, justifying effort or cost, or describing what changed in a release. Translates implementation detail into business outcome. Do not use for technical documentation or internal team communication."
---

## EXPLICAR PARA O CLIENTE

Traduzir trabalho técnico em linguagem de negócio, sem infantilizar e sem
esconder informação.

### Princípio

O cliente não quer saber COMO foi feito. Quer saber O QUE mudou para
ele, QUANTO isso custou de tempo e SE tem risco. Falar de resultado,
não de implementação.

### Tradução — antes e depois

"Implementei RLS no Supabase e políticas por tenant"
→ "Cada cliente agora só enxerga os próprios dados. Mesmo que alguém
   tente acessar informação de outra conta, o sistema bloqueia."

"Refatorei o componente e extraí a lógica para um hook"
→ "Reorganizei essa parte do sistema. Não muda nada visualmente, mas as
   próximas alterações nessa tela ficam mais rápidas e com menos risco
   de quebrar algo."

"Adicionei validação de assinatura no webhook do Stripe"
→ "Garanti que só o Stripe consegue confirmar um pagamento no sistema.
   Antes, em tese, alguém poderia forjar uma confirmação."

### Estrutura de um resumo de entrega

1. O QUE FOI ENTREGUE — em uma frase, do ponto de vista do usuário.
2. O QUE MUDA NA PRÁTICA — o que ele vai notar ao usar.
3. O QUE NÃO ESTÁ INCLUÍDO — evita expectativa errada.
4. PRÓXIMO PASSO — o que vem agora ou o que precisa dele.

### Ao comunicar problema ou atraso

- Dizer logo, sem enrolar até o prazo estourar.
- Explicar o impacto real (o que trava, o que não trava).
- Trazer a solução e o novo prazo junto com o problema.
- Assumir o que for responsabilidade sua, sem se rebaixar nem culpar
terceiros gratuitamente.

### Ao justificar esforço

Comparar com algo tangível, sem tecnicismo:
"Parece uma mudança pequena na tela, mas ela depende de cinco outros
pontos do sistema. Alterar sem ajustar esses pontos quebraria o
faturamento."

### Proibido

- Sigla e jargão sem tradução (RLS, JWT, CORS, refactor, deploy).
- Detalhe de implementação que ele não pode usar para decidir nada.
- Minimizar risco real para evitar conversa difícil.
- Prometer prazo sem margem.
- Tom condescendente. Cliente leigo em tecnologia não é leigo no negócio
dele.

### Formato

Texto curto, em parágrafos. Lista só quando são itens realmente
paralelos. Sem cabeçalho corporativo desnecessário.

### Ao final, entregar

O resumo pronto para copiar e enviar, no canal indicado (e-mail,  
WhatsApp ou reunião).