---
name: "design-system"
description: "Use when creating any new screen, page, or UI component, and when reviewing existing interface code for visual consistency. Defines the project's colors, typography, spacing, radius, shadows, component variants, and content tone so every screen looks like it belongs to the same product. Consult before writing any styling, not after."
---

## DESIGN SYSTEM

FRONTEIRA: esta skill é a DONA de todo valor visual concreto — cor,
tipografia, espaçamento, raio, sombra e breakpoints. Nenhuma outra skill
define esses números; as demais apenas referenciam os tokens daqui. Para
acesso, ver acessibilidade. Para comportamento em tela pequena, ver
mobile-first.

Regra base: NENHUM valor visual hardcoded. Cor, espaçamento, raio, sombra
e tamanho de fonte vêm sempre de tokens. Se o token não existe, criar o
token — nunca escrever o valor solto no componente.

### Tokens (definir uma vez, usar sempre)

- COR: primária, secundária, neutros (5 a 7 tons), sucesso, alerta, erro,
informação. Cada uma com variação de hover e disabled.
- TIPOGRAFIA: uma família para títulos, uma para corpo (ou uma só, com
pesos distintos). Escala definida (ex: 12 / 14 / 16 / 20 / 24 / 32 / 48).
- ESPAÇAMENTO: escala consistente baseada em 4px (4, 8, 12, 16, 24, 32,
48, 64). Nunca valores arbitrários como 13px ou 27px.
- RAIO: 2 a 3 opções no máximo (ex: 4px, 8px, full).
- SOMBRA: 3 níveis (sutil, média, elevada). Não inventar sombras novas.
- BREAKPOINTS: definidos aqui e usados por todas as outras skills.
Referência: 640 / 768 / 1024 / 1280. Sempre em `min-width`.

### Tipografia

- Hierarquia clara: título, subtítulo, corpo, legenda, label.
- Corpo de texto entre 16px e 18px — nunca menos de 14px.
- Altura de linha: 1.5 para corpo, 1.2 para títulos.
- Largura máxima de bloco de texto: 65–75 caracteres.
- Peso e tamanho criam hierarquia. Cor sozinha, não.

### Componentes — variantes fixas

- BOTÃO: primário, secundário, terciário/ghost, destrutivo. Estados:
padrão, hover, ativo, foco, desabilitado, carregando.
- INPUT: padrão, foco, erro, desabilitado, somente leitura.
- CARD, MODAL, TOAST, TABELA, BADGE: um padrão único, reutilizado.
Nunca criar uma variante nova sem adicioná-la ao sistema.

### Layout

- Grid e breakpoints definidos e respeitados.
- Espaçamento generoso — respiro é qualidade percebida.
- Alinhamento consistente; nada "quase alinhado".
- Mobile first.

### Tom de voz do conteúdo

- Direto e humano. Sem jargão corporativo.
- Botão descreve a ação ("Salvar alterações", não "OK").
- Mensagem de erro diz o que aconteceu e o que fazer.
- Sem emoji em interface, salvo decisão explícita do projeto.
- Português correto, sem "Simplifique seu fluxo de trabalho" e afins.

### Proibido

- Valor de cor ou espaçamento escrito direto no componente.
- Fonte fora da definida no sistema.
- Componente duplicado com estilo levemente diferente.
- Estilo inline para resolver caso pontual.

### Ao final, reportar

Quais tokens e componentes existentes foram usados e se algum token novo  
precisou ser criado (e por quê).