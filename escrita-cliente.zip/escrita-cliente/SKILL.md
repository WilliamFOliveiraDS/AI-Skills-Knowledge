---
name: "escrita-cliente"
description: "Use when writing any text that a real user or client will read: button labels, error messages, empty states, tooltips, confirmation dialogs, transactional emails, onboarding copy, or landing page content. Covers tone of voice, clarity, and Brazilian Portuguese conventions. Do not use for code comments, documentation, or internal technical writing."
---

## ESCRITA PARA O USUÁRIO (MICROCOPY)

Todo texto de interface é parte do produto. Escrever como uma pessoa
competente explicando para outra — não como um sistema falando.

### Princípios

- CLARO acima de esperto. Nunca sacrificar entendimento por criatividade.
- CURTO. Cortar toda palavra que não muda o sentido.
- ESPECÍFICO. "Salvar alterações" é melhor que "OK". "Excluir cliente"
é melhor que "Confirmar".
- HUMANO. Sem jargão técnico e sem tom corporativo vazio.
- Tratar o usuário por "você". Nunca "o usuário deve...".

### Botões

- Verbo no infinitivo descrevendo a ação: Salvar, Excluir, Enviar
proposta, Adicionar item.
- O botão diz o que ACONTECE ao clicar, não onde você está.
- Ação destrutiva nomeia o que será destruído: "Excluir 3 pedidos".
- Nunca: OK, Continuar, Prosseguir, Clique aqui, Enviar (sozinho).

### Mensagens de erro — estrutura em 3 partes

1. O QUE aconteceu, em linguagem comum.
2. POR QUÊ, se ajudar.
3. O QUE FAZER agora.

Errado: "Erro 422: Unprocessable entity".
Certo: "Não foi possível salvar. O CPF informado é inválido — confira os
números e tente novamente."

- Nunca culpar o usuário ("você digitou errado").
- Nunca expor erro técnico, stack trace ou código interno cru.
- Se o erro é do sistema, assumir: "Tivemos um problema ao processar.
Já fomos avisados. Tente novamente em alguns minutos."

### Estados vazios

Não deixar tela em branco. Dizer o que é aquilo, por que está vazio e
qual a próxima ação:
"Nenhum cliente cadastrado ainda. Adicione o primeiro para começar a
acompanhar seus atendimentos." + botão de ação.

### Confirmações

- Confirmar apenas ação destrutiva ou irreversível.
- Dizer exatamente o que será feito e se dá para desfazer.
- Botão da confirmação repete a ação: "Sim, excluir" e não "Confirmar".

### Formulários

- Label diz o que é; placeholder dá exemplo — nunca substituir label.
- Explicação de formato antes do erro, não depois.
- Sucesso confirma o que aconteceu: "Cliente salvo."

### E-mails transacionais

- Assunto direto, sem clickbait.
- Primeira linha entrega a informação principal.
- Uma ação principal por e-mail.
- Assinar como pessoa/empresa, não como "Equipe do Sistema".

### Proibido

- "Simplifique seu fluxo de trabalho", "revolucione", "solução completa"
e afins.
- Emoji em interface funcional.
- CAPS LOCK para dar ênfase.
- Exclamação em excesso.
- Traduções literais do inglês ("deletar" em vez de "excluir").

### Ao final, reportar

Textos criados ou alterados, e por que cada mensagem de erro orienta uma  
ação concreta.