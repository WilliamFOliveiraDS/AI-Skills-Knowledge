---
name: "lgpd-compliance"
description: "Use when building or reviewing any feature that collects, stores, displays, exports, or deletes personal data: signup forms, contact forms, user profiles, checkout, analytics, cookies, newsletters, or CRM integrations. Covers legal basis, consent, data subject rights, retention, and privacy notices under Brazilian LGPD. Do not use for features that handle no personal data."
---

## LGPD — CONFORMIDADE

Aplicar sempre que houver coleta, armazenamento, exibição, exportação ou
exclusão de dado pessoal.

### Antes de coletar, definir

1. QUAIS dados serão coletados (listar campo a campo).
2. PARA QUÊ (finalidade específica, não genérica).
3. BASE LEGAL: consentimento, execução de contrato, obrigação legal,
  legítimo interesse, etc. Toda coleta precisa de uma.
4. POR QUANTO TEMPO serão guardados.
5. COM QUEM serão compartilhados (operadores: Supabase, AWS, Stripe...).

### Minimização (regra central)

Coletar APENAS o estritamente necessário para a finalidade declarada.
Se o campo não é usado por nenhuma funcionalidade, não pedir. Questionar
todo campo "para o caso de precisar depois" — isso viola a LGPD.

### Dado pessoal sensível

Origem racial/étnica, convicção religiosa, opinião política, filiação
sindical, dado de saúde, vida sexual, genético e biométrico exigem
proteção reforçada e, em regra, consentimento específico e destacado.
Evitar coletar; se inevitável, criptografar em repouso e restringir
acesso ao mínimo de pessoas.

### Consentimento (quando for a base legal)

- Livre, informado, inequívoco e para finalidade específica.
- Nunca pré-marcado. Nunca embutido em "aceito os termos" genérico.
- Registrar: quem consentiu, quando, para quê, qual versão do texto.
É obrigação provar o consentimento (não repúdio).
- Revogação deve ser tão fácil quanto o consentimento.

### Direitos do titular — implementar de fato

- Acessar os próprios dados (exportação em formato legível).
- Corrigir dados incorretos.
- Excluir dados (com atenção ao que a lei obriga a reter).
- Saber com quem foram compartilhados.
- Revogar consentimento a qualquer momento.
- Portabilidade quando aplicável.
Canal claro para exercer esses direitos, com prazo de resposta definido.

### Cookies

- Banner ANTES de ativar qualquer cookie não essencial.
- Opção REAL de recusar, com o mesmo destaque de aceitar.
- Granularidade por categoria (necessário / analytics / marketing).
- Registrar a escolha e permitir alterar depois.

### Segurança do dado

- Criptografia em trânsito (HTTPS) e em repouso para dados sensíveis.
- Acesso restrito por perfil (menor privilégio).
- Não usar dado real de cliente em ambiente de desenvolvimento.
- Log de acesso a dados sensíveis.

### Documentos do site

Política de Privacidade e Termos de Uso acessíveis, em linguagem clara,
com: quais dados, finalidade, base legal, compartilhamento, retenção,
direitos do titular, contato do encarregado (DPO).

### Ao final, reportar

Campos coletados e sua justificativa, base legal, onde o consentimento é  
registrado, como o titular exerce os direitos, e prazo de retenção.