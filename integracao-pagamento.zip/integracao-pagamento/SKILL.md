---
name: "integracao-pagamento"
description: "Use when implementing or reviewing anything involving payments: checkout, subscriptions, plan upgrades, refunds, invoices, webhooks from Stripe, Pagar.me, Asaas, Mercado Pago, or any payment provider. Covers webhook signature verification, idempotency, payment state machine, reconciliation, and PCI boundaries. Errors here cost real money — apply strictly."
---

## INTEGRAÇÃO DE PAGAMENTO

Área onde erro custa dinheiro real e gera problema jurídico. Nada aqui é
opcional.

### Regra de ouro

NUNCA confiar no frontend para confirmar pagamento. O frontend pode
mostrar "processando"; quem confirma é o webhook validado no servidor.
Um usuário pode fechar a aba, perder conexão ou forjar a chamada.

### Chaves

- Chave secreta apenas no servidor/BFF, via Secrets. Nunca no bundle.
- Chave pública no frontend, apenas para tokenizar.
- Chaves de teste em dev, de produção só em produção.
- Usar chave com escopo restrito quando o provedor permitir.

### Webhooks — obrigatório

1. VERIFICAR A ASSINATURA com o secret do provedor antes de qualquer
  ação. Sem isso, qualquer um simula "pagamento aprovado".
2. Validar sobre o RAW BODY, não sobre o JSON já parseado.
3. IDEMPOTÊNCIA: o mesmo evento chega mais de uma vez. Guardar o ID do
  evento processado e ignorar repetição. Nunca creditar duas vezes.
4. Responder 2xx rápido; processar pesado em background. Timeout faz o
  provedor reenviar.
5. Validar que o evento é do ambiente correto (não aceitar evento de
  teste em produção).
6. Logar todo evento recebido para auditoria.

### Máquina de estados do pagamento

Definir explicitamente e nunca pular etapas:
pendente → processando → aprovado / recusado / estornado / expirado

- Cada transição registrada com timestamp e origem.
- Liberação de acesso SOMENTE no estado aprovado, via webhook.
- Tratar recusa com mensagem clara e caminho de retry.

### Valores

- Trabalhar SEMPRE em centavos, inteiro. Nunca float para dinheiro.
- Calcular o valor no SERVIDOR. Nunca aceitar preço vindo do cliente.
- Validar cupom/desconto no servidor, com limite e validade.
- Conferir moeda em toda operação.

### Dados de cartão

- NUNCA passar pelo seu servidor nem pelo seu banco. Usar o elemento
seguro do provedor (Stripe Elements, checkout hospedado).
- Guardar apenas o token e os últimos 4 dígitos.
- Isso mantém o escopo PCI mínimo.

### Assinaturas

- Tratar renovação, falha de cobrança, período de graça, cancelamento e
reativação.
- Downgrade/upgrade com cálculo proporcional definido.
- Não remover acesso na hora da falha — dar janela de retentativa.

### Reconciliação

- Rotina periódica comparando o estado local com o do provedor.
- Alertar divergências (pago no provedor, pendente no sistema).

### Ao final, reportar

Assinatura de webhook verificada, idempotência implementada, estados  
cobertos, valores calculados no servidor, e o que acontece se o webhook  
falhar.