---
name: "mobile-first"
description: "Use when building or reviewing any screen, layout, navigation, table, or interactive component that real users will open on a phone. Enforces designing from the smallest viewport up, touch target sizing, thumb reach, safe areas, and how dense desktop patterns (tables, sidebars, hover menus) must degrade on small screens. Do not use for admin tools explicitly scoped as desktop-only."
---

## MOBILE FIRST

Regra central: construir a partir da menor tela e ir ADICIONANDO conforme
o espaço cresce. Nunca construir para desktop e depois "ajustar" para
mobile — isso sempre resulta em conteúdo espremido e elemento escondido.

FRONTEIRA: esta skill é a DONA do comportamento em tela pequena — toque,
alcance, degradação de padrões de desktop, safe areas, teclado. Os valores
de breakpoint e espaçamento vêm do design-system, não são definidos aqui.
Contraste e leitor de tela, ver acessibilidade. Otimização de peso, ver
performance-web. Quais estados a tela precisa ter, ver estados-de-tela.

### Ordem de trabalho

1. Layout base sem media query = mobile.
2. Media queries em `min-width` para ampliar, nunca `max-width` para
  consertar.
3. Usar os breakpoints definidos no design-system. Não criar breakpoint
  novo aqui — se o conteúdo exigir um, adicionar ao design-system
   primeiro.

### Alvos de toque

- Mínimo 44x44px de área clicável (não é o tamanho do ícone, é a área).
- Espaçamento mínimo de 8px entre alvos.
- Ação destrutiva longe da ação principal — evitar toque acidental.
- Nada de link de texto pequeno no meio de parágrafo como ação
principal.

### Alcance do polegar

- Ação primária na metade INFERIOR da tela.
- Navegação principal em barra inferior ou menu acessível com uma mão.
- Topo da tela é zona difícil: reservar para título e informação, não
para ação frequente.
- Botão de confirmar/salvar em formulário longo: fixo no rodapé.

### Sem hover

Hover NÃO existe em toque. Toda informação ou ação que dependa de hover
precisa de alternativa: tooltip vira texto visível ou toque; menu
suspenso vira acordeão ou bottom sheet; ação em linha de tabela vira
botão visível ou menu de contexto.
Estado de foco continua obrigatório (teclado externo, acessibilidade).

### Padrões de desktop que precisam degradar

- TABELA: em mobile vira lista de cards, ou scroll horizontal com a
primeira coluna fixa, ou mostra só as colunas essenciais com detalhe
ao toque. Nunca tabela de 8 colunas espremida.
- SIDEBAR: vira menu off-canvas ou barra inferior.
- MODAL GRANDE: vira tela cheia ou bottom sheet.
- MÚLTIPLAS COLUNAS: empilham em uma, na ordem de leitura correta.
- FORMULÁRIO EM LINHA: um campo por linha.

### Tipografia e espaço

- Corpo de texto mínimo 16px — abaixo disso o iOS dá zoom automático no
input.
- Não reduzir fonte para "caber". Reduzir conteúdo.
- Espaçamento generoso: aperto em tela pequena gera erro de toque.
- Largura de leitura confortável, com respiro lateral (mínimo 16px).

### Entrada de dados

- `type` correto no input para abrir o teclado certo (email, tel,
number, url).
- `autocomplete` e `inputmode` configurados.
- Teclado não pode cobrir o campo em foco — rolar até ele.
- Evitar formulário longo: dividir em etapas.
- Preferir seleção a digitação sempre que possível.

### Safe areas e sistema

- Respeitar notch e barra inferior (`env(safe-area-inset-*)`).
- Elemento fixo no rodapé precisa considerar a área segura.
- Testar em modo paisagem — não pode quebrar nem travar.
- Considerar teclado aberto reduzindo a altura útil.

### Performance é parte de mobile

Rede móvel e aparelho modesto são a realidade da maioria. Imagem
otimizada, bundle enxuto e lazy loading não são opcionais aqui.
Ver skill performance-web.

### Proibido

- Conteúdo acessível só no desktop.
- Scroll horizontal não intencional.
- Elemento fixo cobrindo o conteúdo.
- Ação essencial escondida atrás de hover.
- Fonte menor que 14px em qualquer texto funcional.

### Ao final, reportar

Como o layout se comporta em ~375px, o que muda em cada breakpoint,
como tabelas e menus degradaram, e o que foi verificado com teclado
aberto.