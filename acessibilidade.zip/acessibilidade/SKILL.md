---
name: "acessibilidade"
description: "Use when building or reviewing any user interface: forms, modals, menus, tables, buttons, or custom interactive components. Covers WCAG 2.1 AA requirements including keyboard navigation, focus management, color contrast, screen reader labels, and semantic markup. Apply to every screen, not only when accessibility is explicitly requested."
---

## ACESSIBILIDADE (WCAG 2.1 AA)

Padrão mínimo obrigatório em toda interface. Além de inclusão, é
requisito legal (LBI — Lei 13.146/2015) e melhora SEO.

FRONTEIRA: esta skill cuida de acesso — teclado, foco, contraste, leitor
de tela, semântica. Para valores visuais (cor, fonte, espaçamento), ver
design-system. Para comportamento em tela pequena, ver mobile-first.
Para lógica de validação, ver formularios.

### Teclado

- TODA funcionalidade acessível por teclado, sem exceção.
- Ordem de tabulação lógica, seguindo a leitura visual.
- Foco SEMPRE visível — nunca `outline: none` sem substituto claro
(mínimo 2px de contraste com o fundo).
- ESC fecha modal, dropdown e overlay.
- ENTER/SPACE ativam botões e controles customizados.
- Sem armadilha de foco: se entrou, tem que conseguir sair.
- Link "pular para o conteúdo" no início da página.

### Foco em modais e overlays

- Ao abrir: foco vai para dentro do modal.
- Enquanto aberto: foco fica preso dentro dele (focus trap).
- Ao fechar: foco retorna ao elemento que abriu.
- `aria-modal="true"` e `role="dialog"` com `aria-labelledby`.

### Contraste

- Texto normal: mínimo 4.5:1 contra o fundo.
- Texto grande (18pt+ ou 14pt bold): mínimo 3:1.
- Componentes de interface e bordas de input: mínimo 3:1.
- NUNCA usar cor como única forma de transmitir informação (erro em
vermelho precisa também de ícone e texto).

### Semântica e ARIA

- Usar elemento nativo sempre que possível: `<button>` para ação,
`<a>` para navegação. Nunca `<div onClick>`.
- ARIA só quando o HTML nativo não resolve — ARIA errado é pior que
nenhum ARIA.
- `aria-label` ou texto visível em todo botão de ícone.
- `aria-live="polite"` para mensagens dinâmicas (toast, validação).
- `aria-expanded`, `aria-controls` em acordeões e dropdowns.
- `aria-current="page"` no item ativo da navegação.

### Formulários

- Todo input tem `<label>` associado por `htmlFor`/`id` — placeholder
NÃO é label.
- Erro associado ao campo via `aria-describedby` e anunciado.
- Campos obrigatórios marcados com `required` e indicação visual textual.
- Agrupar rádios e checkboxes em `<fieldset>` com `<legend>`.

### Imagens e mídia

- `alt` descritivo; `alt=""` em decorativa.
- Vídeo com legenda; áudio com transcrição.
- Nada com autoplay de som.
- Respeitar `prefers-reduced-motion` em animações.

### Estrutura

- Um `<h1>` por página, hierarquia sem pular níveis.
- Landmarks: header, nav, main, footer.
- `lang` correto no html.
- Zoom até 200% sem quebrar o layout.

### Ao final, reportar

Navegação por teclado testada, contraste verificado, labels presentes,  
foco gerenciado em overlays, e qualquer ponto que não atingiu AA.