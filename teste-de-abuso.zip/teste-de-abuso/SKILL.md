---
name: "teste-de-abuso"
description: "Use when a feature involving money, permissions, user data, limits, or multi-step flows is complete and needs adversarial review. Generates business-logic abuse cases that generic security checklists miss: skipped steps, race conditions, negative values, tampered IDs, and privilege escalation. Complements the security knowledge base rather than repeating it."
---

## TESTE DE ABUSO (LÓGICA DE NEGÓCIO)

Checklist de segurança pega o conhecido. Esta skill procura o que é
específico do SEU sistema: falha de lógica de negócio.

Método: para cada funcionalidade, perguntar "o que acontece se eu fizer
isso de um jeito que ninguém previu?".

### 1. Pular etapas do fluxo

- Consigo chamar o endpoint da última etapa direto, sem passar pelas
anteriores? (confirmar pedido sem pagar, ativar conta sem verificar
e-mail, aprovar sem revisar)
- O sistema valida o ESTADO atual antes de permitir a transição, ou
confia na ordem em que a tela chama?
Regra: cada endpoint valida sozinho se a transição é legal.

### 2. Repetir e concorrer

- E se eu clicar duas vezes? Gera cobrança dupla, dois registros?
- E se eu mandar duas requisições SIMULTÂNEAS? (race condition — saldo
de 100 sacado duas vezes vira 200)
- Cupom de uso único aplicado duas vezes ao mesmo tempo passa?
Regra: operação crítica precisa de transação atômica, lock ou chave de
idempotência. Verificar-e-depois-escrever sem atomicidade é falha.

### 3. Valores fora do esperado

- Quantidade negativa (-5 no carrinho pode virar crédito).
- Zero, onde zero não faz sentido.
- Número gigante (overflow, timeout, custo de processamento).
- Decimal onde se espera inteiro.
- String vazia, só espaço, emoji, 10.000 caracteres.
- Data no passado / no futuro distante.
- Desconto maior que o valor total.

### 4. Trocar identificadores

- Trocar o ID na URL, no payload, no cookie: acesso a dado de outro?
- ID de outro tenant/empresa?
- ID de recurso já excluído?
- Enviar campo que não deveria (role, status, preço, saldo)?
Regra: nunca confiar em ID vindo do cliente sem validar posse.

### 5. Escalada de privilégio

- Usuário comum acessa endpoint de admin direto?
- A restrição é só visual (botão escondido) ou o backend bloqueia?
- Consigo me promover editando meu próprio perfil?
- Convite para empresa X dá acesso a dados da empresa Y?

### 6. Limites e cotas

- O limite do plano é verificado no servidor ou só na tela?
- Consigo estourar cota criando registros em paralelo?
- Consigo continuar usando após cancelar/expirar?

### 7. Fluxos de convite, reset e compartilhamento

- Link de convite expira? Pode ser reutilizado? Funciona para outro
e-mail?
- Token de reset de senha é de uso único? Expira?
- Link compartilhado dá acesso além do pretendido?
- Removi o usuário do sistema — a sessão dele continua ativa?

### 8. Cancelamento e exclusão

- Excluir registro que outro registro depende: quebra algo?
- Dados excluídos somem mesmo ou continuam acessíveis por outra rota?
- Cancelamento devolve acesso indevido ou remove acesso pago?

### Ao final, reportar

Lista dos cenários testados, resultado de cada um, e quais viraram  
correção necessária antes de publicar.