---
name: "formularios"
description: "Use when building or reviewing any form: signup, login, checkout, contact, settings, or multi-step wizards. Covers validation timing, error messaging, loading and submit states, duplicate submission, Brazilian field masks (CPF, CNPJ, CEP, phone), and recovery from partial failure. Forms are where most UX bugs live."
---

## FORMULÁRIOS

Formulário concentra a maior parte dos bugs de UX e de validação. Tratar
com o mesmo rigor de um endpoint.

FRONTEIRA: esta skill é a DONA da lógica do formulário — validação,
estados de envio, duplo envio, máscaras brasileiras. Para labels e
associação de erro por ARIA, ver acessibilidade. Para teclado, tipo de
input e um campo por linha no celular, ver mobile-first. Para o texto das
mensagens, ver escrita-cliente.

### Validação — onde e quando

- SEMPRE validar no servidor. A validação do cliente é conveniência,
não segurança.
- Mesmo schema (Zod) compartilhado entre cliente e servidor quando
possível.
- No cliente: validar ao SAIR do campo (blur), não a cada tecla.
- Depois que o campo já errou uma vez, aí sim revalidar enquanto digita
— para o erro sumir assim que corrigir.
- Nunca validar tudo só no submit sem indicar qual campo falhou.

### Erros

- Erro aparece ao lado do campo, não só num alerta no topo.
- Se houver erro, focar/rolar até o primeiro campo com problema.
- Mensagem diz o que fazer: "O CPF deve ter 11 dígitos" e não
"Campo inválido".
- Associar ao campo com `aria-describedby` (ver skill acessibilidade).
- Erro do servidor mapeado para o campo correspondente quando possível.

### Estados do envio

Obrigatório cobrir todos:

- Repouso.
- Enviando: botão desabilitado + indicação visual de carregamento.
- Sucesso: confirmação clara do que aconteceu e para onde ir.
- Erro de validação: campos marcados.
- Erro de servidor: mensagem + possibilidade de tentar de novo SEM
perder o que foi digitado.

### Duplo envio — obrigatório

- Desabilitar o botão no primeiro clique.
- Bloquear submit por ENTER durante o envio.
- Idempotência no servidor para operação crítica (pagamento, cadastro).
Perder isso gera pedido duplicado e cobrança dupla.

### Campos brasileiros

- CPF/CNPJ: máscara + validação de dígito verificador real (não só
quantidade de dígitos).
- CEP: máscara + busca de endereço automática, mas SEMPRE permitindo
edição manual.
- Telefone: aceitar com e sem 9º dígito, com e sem DDD formatado.
- Data: formato brasileiro na exibição, ISO no armazenamento.
- Moeda: exibir em R$ formatado, armazenar em centavos inteiros.
- Enviar ao servidor o valor limpo, sem máscara.

### Usabilidade

- `type` correto no input (email, tel, number) para abrir o teclado
adequado no celular.
- `autocomplete` correto (name, email, tel, cc-number, postal-code).
- Ordem de tabulação natural.
- Campo obrigatório indicado visualmente e por texto.
- Não pedir confirmação de e-mail/senha se houver opção de ver o que
foi digitado.
- Não limpar o formulário inteiro por causa de um erro.

### Formulário longo ou em etapas

- Dividir em passos com indicação de progresso.
- Salvar rascunho ou preservar estado ao voltar.
- Permitir voltar sem perder o preenchido.
- Validar por etapa, não só no final.

### Segurança

- Rate limiting em formulário público.
- Captcha em cadastro, login, reset e contato.
- Lista branca de campos aceitos no servidor (sem mass assignment).
- Sanitizar entrada que será exibida depois.

### Ao final, reportar

Validações aplicadas (cliente e servidor), estados cobertos, proteção  
contra duplo envio, e máscaras usadas.