---
name: "auditoria-de-projeto-existente"
description: "Use when taking over an unfamiliar or legacy codebase before making changes: inherited projects, client handovers, or code written long ago. Produces a diagnostic report covering architecture, secrets, authentication, routes, dependencies, and risk areas. Read-only by default — do not refactor during the audit."
---

## AUDITORIA DE PROJETO EXISTENTE

Para quando se assume um código que não foi escrito por você. Objetivo:
entender o estado real ANTES de mexer. Nesta fase, NÃO refatorar e NÃO
"melhorar de passagem" — só diagnosticar e reportar.

### 1. Mapa geral

- Stack, versões, framework e gerenciador de pacotes.
- Estrutura de pastas e o padrão arquitetural aparente (se há algum).
- Como o projeto roda localmente: passos, variáveis necessárias.
- Como e onde é feito o deploy.
- Existe README útil? Existe teste? Existe CI?

### 2. Segurança — prioridade máxima

- Há chave, token ou senha no código ou em `.env` commitado? Buscar por
padrões (sk_, api_key, password, secret, Bearer).
- A chave admin/service_role aparece no frontend?
- Como funciona a autenticação? Token onde (localStorage ou cookie)?
- JWT é verificado ou só decodificado?
- Existe checagem de AUTORIZAÇÃO por rota, ou só de login?
- RLS está ativo? As tabelas sensíveis estão protegidas?
- Queries são parametrizadas ou há concatenação de string?
- Upload aceita qualquer arquivo?
Qualquer item crítico encontrado deve ser reportado IMEDIATAMENTE, antes
de continuar a auditoria.

### 3. Rotas e integrações

- Listar todas as rotas/endpoints existentes.
- Mapear quem consome o quê (dependências entre endpoints).
- Listar integrações externas e onde ficam as credenciais.
- Identificar rota órfã (existe e ninguém chama) e referência quebrada
(chamam e não existe).
- Testar se as integrações externas ainda respondem.

### 4. Dados

- Esquema do banco: tabelas, relações, o que guarda dado pessoal.
- Existe migração versionada ou o banco foi alterado à mão?
- Há dado real de cliente em ambiente de desenvolvimento?
- Existe backup? Alguém já testou restaurar?

### 5. Dependências

- Rodar auditoria de vulnerabilidade.
- Identificar pacote abandonado ou muito desatualizado.
- Identificar dependência instalada e não usada.
- Verificar se o lockfile existe e está commitado.

### 6. Zonas de risco

Identificar e sinalizar:

- Arquivo enorme com muita responsabilidade (mexer ali é perigoso).
- Trecho sem tipo, com `any` espalhado.
- Lógica de negócio duplicada em vários lugares.
- Código comentado em massa.
- Parte do sistema que ninguém entende e todos evitam.

### 7. Relatório final — entregar antes de qualquer alteração

1. Resumo executivo: o projeto está em que estado.
2. CRÍTICO: o que precisa ser corrigido antes de qualquer coisa
  (segurança, dado exposto, backup inexistente).
3. IMPORTANTE: o que gera risco no médio prazo.
4. MELHORIA: o que é dívida técnica tolerável.
5. Mapa de rotas e dependências.
6. O que NÃO deve ser tocado sem planejamento (e por quê).
7. Estimativa de esforço para estabilizar.

### Regra final

Não iniciar refatoração durante a auditoria. Diagnóstico primeiro,  
priorização depois, mudança por último — uma de cada vez.