---
name: "performance-web"
description: "Use when building or reviewing pages that must load fast: public pages, landing pages, listings, dashboards with heavy data, or any screen reported as slow. Covers Core Web Vitals, bundle size, image optimization, rendering strategy, and unnecessary re-renders. Performance affects both search ranking and conversion."
---

## PERFORMANCE WEB

Meta: LCP abaixo de 2,5s, INP abaixo de 200ms, CLS abaixo de 0,1.
Performance é ranking no Google e é conversão — não é detalhe estético.

FRONTEIRA: esta skill é a DONA de velocidade — imagem, bundle, render,
rede, banco. Para quais estados a tela precisa ter, ver estados-de-tela.
Para comportamento em tela pequena, ver mobile-first. Para meta tags e
indexação, ver seo-onpage.

### Imagens (maior ganho na maioria dos sites)

- Formato moderno: WebP ou AVIF, com fallback.
- Dimensionar no tamanho real de exibição — nunca servir 3000px para
exibir em 400px.
- `width` e `height` sempre definidos (evita CLS).
- `loading="lazy"` abaixo da dobra; a imagem principal (LCP) NÃO deve
ser lazy.
- `srcset` para servir tamanho adequado por dispositivo.
- Comprimir antes de subir.

### JavaScript

- Medir o bundle antes de otimizar. Identificar o que mais pesa.
- Code splitting por rota.
- Import dinâmico para o que não é necessário no primeiro render
(modal, editor, gráfico, mapa).
- Evitar biblioteca inteira para uma função (importar só o necessário).
- Remover dependência que dá para resolver com código próprio pequeno.
- Sem polyfill desnecessário.

### Fontes

- Máximo 2 famílias, com os pesos realmente usados.
- `font-display: swap`.
- Preload da fonte crítica.
- Preferir fonte do sistema quando o projeto permitir.

### Renderização

- Conteúdo estático: gerar estático (SSG) ou cachear.
- Conteúdo público que muda pouco: ISR/revalidação.
- Só usar client-side rendering onde há interação real.
- Streaming e suspense para não bloquear a tela inteira por um dado
lento.

### Re-render (React)

- Não criar objeto/array/função nova em prop dentro do render sem
necessidade.
- `useMemo`/`useCallback` onde há custo real — não em tudo por reflexo.
- Lista longa: virtualização.
- Estado no nível mais baixo possível — estado global re-renderiza
demais.
- Key estável em lista (nunca índice em lista que muda de ordem).

### Rede

- Evitar cascata de requisições (fetch que depende de fetch que depende
de fetch). Agregar no BFF.
- Paginar listas grandes — nunca trazer tudo.
- Cache de resposta com política definida.
- Comprimir resposta (gzip/brotli).
- Preconnect para domínio de terceiro crítico.

### Terceiros

- Cada script de terceiro (analytics, chat, pixel) custa performance.
Questionar cada um.
- Carregar de forma assíncrona/diferida.
- Nunca no bloqueio do render inicial.

### Banco

- Índice nas colunas usadas em filtro e ordenação.
- Evitar N+1 (uma query por item da lista).
- Selecionar só as colunas necessárias.

### Ao final, reportar

O que foi otimizado, impacto estimado, e o que ficou pendente por
exigir mudança maior.