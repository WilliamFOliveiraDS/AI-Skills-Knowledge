---
name: "debug-sistematico"
description: "Use when something is broken, failing, or behaving unexpectedly: an error appears, a request fails, data does not load, a feature stopped working after a change, or a bug is reported. Enforces reproduce-isolate-hypothesize-verify instead of guessing fixes. Do not use for building new features or planned refactors."
---

## DEBUG SISTEMÁTICO

Regra central: NÃO SAIR CORRIGINDO POR TENTATIVA. Cada mudança feita sem
hipótese confirmada acrescenta ruído e pode criar um segundo bug.

### Passo 1 — Reproduzir

- Qual a sequência exata que causa o problema?
- Acontece sempre ou de forma intermitente?
- Acontece para todo usuário ou só para um perfil/conta?
- Acontece em todo ambiente ou só em produção?
Se não consegue reproduzir, não corrija ainda — colete mais informação.

### Passo 2 — Coletar evidência

- Mensagem de erro COMPLETA (não a resumida).
- Console do navegador: erro de JS.
- Aba Rede: status HTTP, payload enviado, resposta recebida.
- Log do servidor no momento do erro.
- O que exatamente mudou desde a última vez que funcionava?

### Passo 3 — Isolar a camada

Determinar ONDE quebra antes de perguntar por quê:

- É frontend? (dado chegou certo mas renderizou errado)
- É a chamada? (rota errada, 404, CORS, payload malformado)
- É o BFF? (erro na agregação, transformação, autenticação)
- É a API externa? (fora do ar, credencial expirada, mudou contrato)
- É o banco? (query, permissão, RLS bloqueando)
Testar cada camada isoladamente até achar a fronteira onde o dado se
perde ou muda.

### Suspeitos frequentes — verificar cedo

1. ROTA QUEBRADA: alguma rota foi renomeada/removida e quem consumia
  ficou apontando para o path antigo. Buscar a referência no projeto
   inteiro.
2. Variável de ambiente ausente ou diferente entre ambientes.
3. Credencial expirada ou chave de teste em produção.
4. RLS/permissão bloqueando silenciosamente (retorna vazio, não erro).
5. Cache servindo versão antiga.
6. Dado nulo/indefinido não tratado.
7. Race condition — algo assíncrono resolvendo fora de ordem.
8. Mudança de contrato da API externa.

### Passo 4 — Hipótese

Formular uma hipótese específica e testável: "Acredito que X causa Y,
porque Z". Definir como confirmar ANTES de mexer no código.

### Passo 5 — Corrigir a causa, não o sintoma

- Tratar o motivo real. Try/catch que engole erro não é correção.
- Fazer UMA mudança por vez e verificar.
- Se a correção não resolveu, DESFAZER antes de tentar outra — não
acumular alterações especulativas.

### Passo 6 — Verificar e prevenir

- Confirmar que o caso original funciona.
- Confirmar que nada relacionado quebrou.
- Perguntar: esse bug pode existir em outro lugar do sistema?
- Se for erro recorrente, tratar na origem (validação, tipo, contrato).

### Ao final, reportar

Sintoma, causa raiz identificada, evidência que confirmou, correção  
aplicada, o que foi testado, e se o padrão pode existir em outro ponto.