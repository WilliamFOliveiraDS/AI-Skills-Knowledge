---
name: "seo-onpage"
description: "Use when creating or editing any public-facing page, landing page, blog post, or route that should be found on search engines. Covers meta tags, Open Graph, structured data, heading hierarchy, semantic HTML, internal linking, sitemap and robots. Do not use for authenticated dashboards or internal admin screens, which should be excluded from indexing instead."
---

## SEO ON-PAGE

Aplicar em toda página pública. Páginas autenticadas/admin devem ser
EXCLUÍDAS da indexação (noindex + robots.txt).

### Meta tags obrigatórias por página

- `<title>` único, 50–60 caracteres, com a palavra-chave principal no
início. Nunca repetir o mesmo title em páginas diferentes.
- `<meta name="description">` único, 140–160 caracteres, escrito para
gerar clique (benefício + call to action), não para repetir keyword.
- `<link rel="canonical">` em todas as páginas, apontando para a URL
definitiva (evita conteúdo duplicado por parâmetros de query).
- `<html lang="pt-BR">` correto.
- Viewport meta tag configurada.

### Open Graph e Twitter Card

- og:title, og:description, og:image (1200x630px), og:url, og:type.
- twitter:card = summary_large_image.
- A imagem de OG deve existir de fato e ter URL absoluta.

### Hierarquia de headings

- Um único `<h1>` por página, descrevendo o conteúdo principal.
- H2/H3 em ordem, sem pular níveis. Nunca usar heading por estilo visual
— usar CSS para isso.

### HTML semântico

- Usar `<header>`, `<nav>`, `<main>`, `<article>`, `<section>`,
`<footer>` em vez de `<div>` genérico.
- Um `<main>` por página.
- Links de navegação em `<nav>` com texto descritivo — nunca "clique
aqui" ou "saiba mais" isolado.

### Imagens

- `alt` descritivo em toda imagem de conteúdo; `alt=""` em imagem
decorativa.
- `width` e `height` definidos para evitar layout shift.
- Formatos modernos (WebP/AVIF) com fallback.
- `loading="lazy"` em imagens abaixo da dobra.

### URLs

- Curtas, com hífen, em minúsculas, sem parâmetros desnecessários,
descritivas do conteúdo (`/blog/como-escolher-crm` e não `/post?id=42`).
- Nunca alterar URL de página indexada sem redirect 301.

### Dados estruturados (schema.org, JSON-LD)

Aplicar o tipo adequado: Organization e WebSite no layout base; Article
ou BlogPosting em posts; Product e Offer em produtos; FAQPage em FAQs;
BreadcrumbList em navegação; LocalBusiness quando houver endereço físico.

### Técnico

- `sitemap.xml` gerado e atualizado automaticamente.
- `robots.txt` liberando o público e bloqueando admin/api.
- Links internos entre páginas relacionadas, com âncora descritiva.
- Sem link quebrado (404) na navegação.
- Performance importa para ranking — ver skill de performance-web.

### Ao final, reportar

Title, description, canonical, OG, H1, schema aplicado e status de  
sitemap/robots da(s) página(s) criada(s) ou alterada(s).