---
name: "anti-slop"
description: "Use when writing or reviewing any code or user-facing text, to avoid generic AI-generated patterns. Bans obvious comments, meaningless names, oversized components, type escapes, dead abstraction, and filler marketing copy. Apply as a final pass over generated output before delivering it."
---

## ANTI-SLOP — PROIBIÇÕES DE QUALIDADE

Passada final obrigatória sobre todo código e texto gerado. O objetivo é
que o resultado não pareça gerado por template.

FRONTEIRA: esta skill cuida de qualidade de código e de texto — nomes,
tipos, tamanho, código morto, copy genérica. Para o que escrever de fato
nas mensagens ao usuário, ver escrita-cliente. Para valores visuais, ver
design-system.

### Comentários

PROIBIDO comentar o óbvio:
  // incrementa o contador
  // função que salva o usuário
  // useState para controlar o modal
Comentário só existe para explicar POR QUÊ, nunca O QUÊ. Se o código
precisa de comentário para ser entendido, o problema é o código — melhore
o nome e a estrutura.
Permitido: explicar decisão não óbvia, contornar limitação conhecida,
alertar sobre efeito colateral, referenciar regra de negócio.

### Nomes

PROIBIDO: data, item, obj, temp, result, value, info, handleClick,
handleChange, utils.ts, helpers.ts, index.ts com lógica, Component1.
Nome deve dizer o que a coisa É ou FAZ no domínio:
  data → pedidosPendentes
  handleClick → cancelarAssinatura
  utils.ts → formatacaoMoeda.ts
Booleano começa com is/has/can/should. Função começa com verbo.

### Tipos (TypeScript)

- `any` é proibido. Se não sabe o tipo, descubra ou use `unknown` com
narrowing.
- Sem `@ts-ignore` sem justificativa escrita.
- Sem `as` para calar o compilador.
- Tipar retorno de função pública e resposta de API.

### Tamanho e estrutura

- Componente acima de ~150 linhas: dividir.
- Função acima de ~40 linhas: dividir.
- Mais de 3 níveis de aninhamento: extrair ou inverter com early return.
- Componente que faz fetch, transforma, valida e renderiza: separar
responsabilidades.

### Abstração

- Não criar camada de abstração para um único caso de uso.
- Não criar componente genérico "para o futuro" — resolver o problema
de hoje.
- Duas ocorrências não justificam abstrair; três começam a justificar.
- Prop booleana demais (isX, isY, isZ) indica que deveriam ser
componentes distintos.

### Código morto

- Sem função não usada, import não usado, variável não usada.
- Sem bloco comentado "para caso precise" — isso é o que o git faz.
- Sem console.log esquecido.
- Sem TODO sem dono e sem contexto.

### Erros

- Sem `catch (e) {}` vazio.
- Sem `catch` que só faz console.log e segue como se nada tivesse
acontecido.
- Erro tratado ou propagado — nunca engolido.

### Texto de interface

PROIBIDO: "Simplifique seu fluxo de trabalho", "solução completa",
"revolucione", "leve seu negócio para o próximo nível", "descomplicado",
"tudo em um só lugar", emoji em botão, exclamação em excesso.
Escrever o que a coisa faz, concretamente. Ver skill escrita-cliente.

### Ao final, reportar

O que foi renomeado, o que foi dividido, o que foi removido, e qualquer
`any`/`ts-ignore` que tenha permanecido e por quê.